﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HastaneRandevuSistemi.Models
{
    public class Brans
    {
        public int ID { get; set; }
        public string BransAdi { get; set; }
            
    }
}
